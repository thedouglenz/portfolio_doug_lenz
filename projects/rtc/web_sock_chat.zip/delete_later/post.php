<?php
require_once 'pusher-lib/Pusher.php';
session_start();

$key='xxx';
$secret='xxx';
$app_id='xxx';
$pusher = new Pusher($key, $secret, $app_id);

if(isset($_POST['message'])) {
	$data = array ('message' => htmlentities(strip_tags($_POST['message'])), 'name'=>$_SESSION['username'] );
	$pusher->trigger('chat-channel', 'send-message', $data);
}

?>